package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SetLocationActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_location)
        var databaseHelper = DatabaseHelper(this)

        var btnConfirmNewLocation=findViewById<Button>(R.id.confirmNewLocation)

        //tha xrisimopoihsoyme ayto to view gia na
        //diksoyme to paron location
        var currentLocation=findViewById<TextView>(R.id.enterCurrentLocationHere)



        //o logos poy prepei na kanoyme ola ta actions entws toy if
        //kai oxi apla to assignment toy usermail
        //einai logo toy pws doyleyei to scope stin kotlin

        //ara exoyme to programma se periptwsi poy erxomaste apo customer
        if(intent.getStringExtra("from")=="customer") {
            //pairnoyme to mail toy xrhsth
            var usermail = intent.getStringExtra("usermail")

            if (usermail != null) {
                //thetoyme to textView sto paron username
                currentLocation.text = databaseHelper.getCustomer(usermail).get(0).location
            }

            //xristis pataei koympi confirm
            btnConfirmNewLocation.setOnClickListener {
                //pairnoyme to neo username
                var newLocation = findViewById<EditText>(R.id.editNewLocation).getText().toString()


                if (usermail != null) {
                    databaseHelper.updateCustomerLocation(usermail,newLocation)
                    Toast.makeText(this,"Location changed successfully", Toast.LENGTH_SHORT).show()
                    //ananewnoyme to Current Username:
                    currentLocation.text = databaseHelper.getCustomer(usermail).get(0).location

                }


            }

        }else if(intent.getStringExtra("from")=="tech"){
            //pairnoyme to mail toy xrhsth
            var usermail = intent.getStringExtra("usermail")


            if (usermail != null) {
                //thetoyme to textView sto paron username
                currentLocation.text = databaseHelper.getTechFromEmail(usermail).get(0).location
            }


            //xristis pataei koympi confirm
            btnConfirmNewLocation.setOnClickListener {
                var usermail = intent.getStringExtra("usermail")

                if (usermail != null) {
                    //thetoyme to textView sto paron location
                    currentLocation.text = databaseHelper.getTechFromEmail(usermail).get(0).location
                }
                //pairnoyme to neo username
                var newLocation = findViewById<EditText>(R.id.editNewLocation).getText().toString()


                if (usermail != null) {
                    databaseHelper.updateTechLocation(usermail,newLocation)
                    Toast.makeText(this,"Location changed successfully", Toast.LENGTH_SHORT).show()
                    //ananewnoyme to CurrentLocation
                    currentLocation.text = databaseHelper.getTechFromEmail(usermail).get(0).location


                }


            }

        }
    }
}