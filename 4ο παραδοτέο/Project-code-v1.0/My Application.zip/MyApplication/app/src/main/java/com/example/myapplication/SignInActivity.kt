package com.example.myapplication

import Customer
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat


class SignInActivity:AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        var databaseHelper=DatabaseHelper(this)


        // parolo poy einai depricated htan makran i pio leitoyrgiki epilogi
       // val customer1=intent.getSerializableExtra("customer1") as Customer

        //println(customer1.password)

        val btnSignInConfirm=findViewById<Button>(R.id.confirmAccountButton)

        btnSignInConfirm.setOnClickListener{

            val editEmail=findViewById<EditText>(R.id.editEmail)
            val editPassword=findViewById<EditText>(R.id.editPassword)

            //pairnoyme to inputed mail kai password
            val enteredEmail=editEmail.getText().toString()
            val enteredPassword=editPassword.getText().toString()

            //an idia me ta attributes, proxorame stin epomeni othoni

            //aplo check oti ontws egine pass to object
           // println(customer1.name)

            //kaloyme signIn method me inputted stoixeia
            //customer1.signIn(enteredEmail,enteredPassword)

            //kanoyme sign in
          /*  if(customer1.isSignedIn==true) {
                //edw tha itan kalo na kaname ena check toy type toy object
                //etsi wste otan einai technician na paei se allo screen apo otan
                //user
                Intent(this, MenuActivity::class.java).also {
                    it.putExtra("customer1",customer1)
                    it.putExtra("from","SignInActivity")
                    startActivity(it)
               }
             } */
             //neos tropos, me database
            //yparxei mail kai kwdikos
                val customerExists=databaseHelper.readCustomer(enteredEmail,enteredPassword)
                //yparxei to mail, alla oxi aparaitita o kwdikos
                val customerEmailExists=databaseHelper.readCustomerEmail(enteredEmail)
            //omoiws
                val techExists=databaseHelper.readTechnician(enteredEmail,enteredPassword)
                val techEmailExists=databaseHelper.readTechnicianEmail(enteredEmail)
            //elegxoyme an yparxei antistoixos customer
                if(customerExists){
                    Toast.makeText(this,"Sign In successful", Toast.LENGTH_SHORT).show()
                    Intent(this, MenuActivity::class.java).also {
                        //stelnoyme to email toy customer
                        it.putExtra("usermail",enteredEmail)
                        startActivity(it)
                    }
                }else if(customerEmailExists && !customerExists){
                    //lathos kwdikos
                    Toast.makeText(this,"Wrong Password", Toast.LENGTH_SHORT).show()


                } else if(techExists){
                    //elegxoyme an yparxei antistoixos tech
                    Toast.makeText(this,"Sign In successful",Toast.LENGTH_SHORT).show()
                    Intent(this,TechMenuActivity::class.java).also{
                        //stelnoyme to email toy tech
                        it.putExtra("usermail",enteredEmail)
                        startActivity(it)
                    }

                }else if(techEmailExists && !techExists){
                    Toast.makeText(this,"Wrong Password", Toast.LENGTH_SHORT).show()

                }else{
                    Toast.makeText(this,"No such user exists", Toast.LENGTH_SHORT).show()

                }
            }
        }
    }
