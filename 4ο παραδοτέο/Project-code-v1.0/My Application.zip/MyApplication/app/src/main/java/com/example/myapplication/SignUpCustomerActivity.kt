package com.example.myapplication

import Customer
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignUpCustomerActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_sign_up_customer)

        var databaseHelper=DatabaseHelper(this)


        val btnSignUpConfirm = findViewById<View>(R.id.confirmAccountButton)
        btnSignUpConfirm.setOnClickListener {
            //pairnoyme stoixeia
            val username=findViewById<EditText>(R.id.editUsername)
            val email=findViewById<EditText>(R.id.editEmail)
            val password=findViewById<EditText>(R.id.editPassword)

            //prepei prwta na kanoyme getText() alliws den doyleuei
            val objusername=username.getText().toString()
            val objemail=email.getText().toString()
            val objpassword=password.getText().toString()
            val location="Dim votsi 3"

            //vazoyme ta stoixeia sto Database
            val insertedRowId=databaseHelper.insertCustomer(objemail,objpassword,objusername,location)

            if(insertedRowId!=-1L) {
                //toast anakoinwsh
                Toast.makeText(this, "Sign Up Successful", Toast.LENGTH_SHORT).show()
                //ftiaxnoyme ton customer me ta stoixeia poy dothikan
                val customerFromSignUp = Customer(objusername, objpassword, "123", objemail)
                println(customerFromSignUp.name)

                Intent(this, SignInActivity::class.java).also {
                   // it.putExtra("customerFromSignUp", customerFromSignUp)
                    //it.putExtra("from", "SignUpCustomerActivity")
                    startActivity(it)
                }
            }else{
                Toast.makeText(this,"Sign Up Failed",Toast.LENGTH_SHORT).show()
                }


            }
        }
    }
