package com.example.myapplication

import Customer
import Request
import Technician
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.Rating
import android.provider.ContactsContract.CommonDataKinds.Email
import java.lang.reflect.Method

class DatabaseHelper(private val context: Context):SQLiteOpenHelper(context, DATABASE_NAME,null,
    DATABASE_VERSION) {
    //phgh
    //https://www.youtube.com/watch?v=zz659HPTe6M

    companion object {
        private const val DATABASE_NAME = "MyDatabase.db"
        private const val DATABASE_VERSION=4
        //tables
        private const val TABLE_NAME_1="customer"
        private const val TABLE_NAME_2="technician"
        private const val TABLE_NAME_3="problem"
        private const val TABLE_NAME_4="payment"
        private const val TABLE_NAME_5="review"
        private const val TABLE_NAME_6="message"
        private const val TABLE_NAME_7="request"
        //customer pedia
        private const val CUSTOMER_NAME="customer_name"
        private const val CUSTOMER_PASSWORD="customer_password"
        private const val CUSTOMER_EMAIL="customer_email"
        private const val CUSTOMER_LOCATION="customer_location"
        //tech pedia
        private const val TECH_NAME="tech_name"
        private const val TECH_PASSWORD="tech_password"
        private const val TECH_EMAIL="tech_email"
        private const val TECH_LOCATION="tech_location"
        private const val TECH_SKILLS="tech_skills"
        private const val TECH_SPECIALIZATION="tech_specialization"
        private const val TECH_RATING="tech_rating"
        private const val TECH_AVAILABLE="tech_available"
        //problem pedia
        private const val PROBLEM_ID="problem_id"
        private const val PROBLEM_TYPE="problem_type"
        private const val PROBLEM_DESCRIPTION="problem_description"
        private const val PROBLEM_LOCATION="problem_location"
        private const val PROBLEM_CUSTOMER="problem_customer"
        private const val PROBLEM_TECH="problem_tech"
        //request pedia
        private const val REQUEST_ID="request_id"
        private const val REQUEST_TYPE="request_type"
        private const val REQUEST_DESCRIPTION="request_description"
        private const val REQUEST_LOCATION="request_location"
        private const val REQUEST_CUSTOMER="request_customer"
        private const val REQUEST_TECH="request_tech"
        //payment pedia
        private const val PAYMENT_ID="payment_id"
        private const val PAYMENT_AMOUNT="payment_amount"
        private const val PAYMENT_METHOD="payment_method"
        private const val PAYMENT_CUSTOMER="payment_customer"
        private const val PAYMENT_TECH="payment_tech"
        //Review pedia
        private const val RATE_ID="rate_id"
        private const val REVIEW_RATING="review_rating"
        private const val REVIEW_COMMENT="review_comment"
        private const val REVIEW_DATE="review_date"
        private const val REVIEW_CUSTOMER="review_customer"
        private const val REVIEW_TECH="review_tech"
        //Message pedia
        private const val MESSAGE_ID="message_id"
        private const val MESSAGE_TEXT="message_text"
        private const val MESSAGE_DATE="message_date"
        private const val MESSAGE_CUSTOMER="message_customer"
        private const val MESSAGE_TECH="message_tech"



    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createCustomerQuery=("CREATE TABLE $TABLE_NAME_1 (" +
                "$CUSTOMER_EMAIL TEXT PRIMARY KEY, " +
                "$CUSTOMER_NAME TEXT, " +
                "$CUSTOMER_PASSWORD TEXT, " +
                "$CUSTOMER_LOCATION TEXT)")
        val createTechQuery=("CREATE TABLE $TABLE_NAME_2 (" +
                "$TECH_EMAIL TEXT PRIMARY KEY, " +
                "$TECH_NAME TEXT, " +
                "$TECH_PASSWORD TEXT, " +
                "$TECH_LOCATION TEXT, " +
                "$TECH_SKILLS TEXT, "+
                "$TECH_SPECIALIZATION TEXT, "+
                "$TECH_RATING REAL, "+
                "$TECH_AVAILABLE INTEGER)"
                )
        //Ta problem_customer kai problem_tech anaferontai sta antistoixa email
        //efoson einai primary keys
        val createProblemQuery=("CREATE TABLE $TABLE_NAME_3 (" +
                "$PROBLEM_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$PROBLEM_TYPE TEXT, " +
                "$PROBLEM_DESCRIPTION TEXT, " +
                "$PROBLEM_LOCATION TEXT, " +
                "$PROBLEM_CUSTOMER TEXT,"+
                "$PROBLEM_TECH TEXT)"
                )
        val createRequestQuery=("CREATE TABLE $TABLE_NAME_7 (" +
                "$REQUEST_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$REQUEST_TYPE TEXT, " +
                "$REQUEST_DESCRIPTION TEXT, " +
                "$REQUEST_LOCATION TEXT, " +
                "$REQUEST_CUSTOMER TEXT,"+
                "$REQUEST_TECH TEXT)"
                )
        //Omoiws gia tech kai vustomer
        val createPaymentQuery=("CREATE TABLE $TABLE_NAME_4 (" +
                "$PAYMENT_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$PAYMENT_AMOUNT REAL, " +
                "$PAYMENT_METHOD TEXT, " +
                "$PAYMENT_CUSTOMER TEXT,"+
                "$PAYMENT_TECH TEXT)"
                )
        val createReviewQuery=("CREATE TABLE $TABLE_NAME_5 (" +
                "$RATE_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$REVIEW_RATING INTEGER, " +
                "$REVIEW_DATE TEXT, " +
                "$REVIEW_COMMENT TEXT ,"+
                "$REVIEW_TECH TEXT,"+
                "$REVIEW_CUSTOMER TEXT)"
                )
        val createMessageQuery=("CREATE TABLE $TABLE_NAME_6 (" +
                "$MESSAGE_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$MESSAGE_DATE TEXT, " +
                "$MESSAGE_TEXT TEXT, "+
                "$MESSAGE_TECH TEXT,"+
                "$MESSAGE_CUSTOMER TEXT)"
                )

        //Kanoyme execute ta parapanw
        //Queries
        db?.execSQL(createCustomerQuery)
        db?.execSQL(createTechQuery)
        db?.execSQL(createProblemQuery)
        db?.execSQL(createPaymentQuery)
        db?.execSQL(createReviewQuery)
        db?.execSQL(createMessageQuery)
        db?.execSQL(createRequestQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val dropCustomerQuery="DROP TABLE IF EXISTS $TABLE_NAME_1"
        val dropTechQuery="DROP TABLE IF EXISTS $TABLE_NAME_2"
        val dropProblemQuery="DROP TABLE IF EXISTS $TABLE_NAME_3"
        val dropPaymentQuery="DROP TABLE IF EXISTS $TABLE_NAME_4"
        val dropReviewQuery="DROP TABLE IF EXISTS $TABLE_NAME_5"
        val dropMessageQuery="DROP TABLE IF EXISTS $TABLE_NAME_6"
        val dropRequestQuery="DROP TABLE IF EXISTS $TABLE_NAME_7"

        db?.execSQL(dropCustomerQuery)
        db?.execSQL(dropTechQuery)
        db?.execSQL(dropProblemQuery)
        db?.execSQL(dropPaymentQuery)
        db?.execSQL(dropReviewQuery)
        db?.execSQL(dropMessageQuery)
        db?.execSQL(dropRequestQuery)
        onCreate(db)
    }
    //insert function gia customer
    fun insertCustomer(email: String,password:String,name:String,location:String):Long{
        val values=ContentValues().apply{
            put(CUSTOMER_NAME,name)
            put(CUSTOMER_EMAIL,email)
            put(CUSTOMER_PASSWORD,password)
            put(CUSTOMER_LOCATION,location)

        }
        val db=writableDatabase
        return db.insert(TABLE_NAME_1,null,values)
    }
    //insert gia tech
    fun insertTech(email: String,password:String,name:String,location:String,skills:String,specialization:String,rating: Float,available:Int):Long{
        val values=ContentValues().apply{
            put(TECH_NAME,name)
            put(TECH_EMAIL,email)
            put(TECH_PASSWORD,password)
            put(TECH_LOCATION,location)
            put(TECH_SKILLS,skills)
            put(TECH_SPECIALIZATION,specialization)
            put(TECH_RATING,rating)
            put(TECH_AVAILABLE,available)

        }
        val db=writableDatabase
        return db.insert(TABLE_NAME_2,null,values)
    }
    fun insertProblem(id:Int,type:String,description:String,location:String,customer:String,tech:String):Long{
        val values=ContentValues().apply{
            put(PROBLEM_ID,id)
            put(PROBLEM_TYPE,type)
            put(PROBLEM_DESCRIPTION,description)
            put(PROBLEM_LOCATION,location)
            put(PROBLEM_CUSTOMER,customer)
            put(PROBLEM_TECH,tech)

        }
        val db=writableDatabase
        return db.insert(TABLE_NAME_3,null,values)
    }
    fun insertRequest(id:Int,type:String,description:String,location:String,customer:String,tech:String):Long{
        val values=ContentValues().apply{
            put(REQUEST_ID,id)
            put(REQUEST_TYPE,type)
            put(REQUEST_DESCRIPTION,description)
            put(REQUEST_LOCATION,location)
            put(REQUEST_CUSTOMER,customer)
            put(REQUEST_TECH,tech)

        }
        val db=writableDatabase
        return db.insert(TABLE_NAME_7,null,values)
    }
    fun insertPayment(id:Int,amount:Float,method: String,customer:String,tech:String):Long{
        val values=ContentValues().apply{
            put(PAYMENT_ID,id)
            put(PAYMENT_METHOD,method)
            put(PAYMENT_AMOUNT,amount)
            put(PAYMENT_CUSTOMER,customer)
            put(PAYMENT_TECH,tech)

        }
        val db=writableDatabase
        return db.insert(TABLE_NAME_4,null,values)
    }
    fun insertReview(id:Int,rating: Int,date:String,comment:String,customer:String,tech:String):Long{
        val values=ContentValues().apply{
            put(RATE_ID,id)
            put(REVIEW_RATING,rating)
            put(REVIEW_DATE,date)
            put(REVIEW_COMMENT,comment)
            put(REVIEW_CUSTOMER,customer)
            put(REVIEW_TECH,tech)

        }
        val db=writableDatabase
        return db.insert(TABLE_NAME_5,null,values)
    }
    fun insertMessage(id:Int,date:String,text:String,customer:String,tech:String):Long{
        val values=ContentValues().apply{
            put(MESSAGE_ID,id)
            put(MESSAGE_DATE,date)
            put(MESSAGE_TEXT,text)
            put(MESSAGE_CUSTOMER,customer)
            put(MESSAGE_TECH,tech)

        }
        val db=writableDatabase
        return db.insert(TABLE_NAME_6,null,values)
    }
    fun readCustomer(email: String,password:String):Boolean{
        val db=readableDatabase
        val selection="$CUSTOMER_EMAIL = ? AND $CUSTOMER_PASSWORD= ?"
        val selectionArgs=arrayOf(email,password)
        val cursor=db.query(TABLE_NAME_1,null,selection,selectionArgs,null,null,null)

        val customerExists=cursor.count>0
        cursor.close()
        return customerExists

    }
    fun readCustomerEmail(email: String):Boolean{
        val db=readableDatabase
        val selection="$CUSTOMER_EMAIL = ?"
        val selectionArgs=arrayOf(email)
        val cursor=db.query(TABLE_NAME_1,null,selection,selectionArgs,null,null,null)

        val customerExists=cursor.count>0
        cursor.close()
        return customerExists

    }
    fun readTechnician(email: String,password:String):Boolean{
        val db=readableDatabase
        val selection="$TECH_EMAIL = ? AND $TECH_PASSWORD= ?"
        val selectionArgs=arrayOf(email,password)
        val cursor=db.query(TABLE_NAME_2,null,selection,selectionArgs,null,null,null)

        val techExists=cursor.count>0
        cursor.close()
        return techExists
    }
    fun readTechnicianEmail(email: String):Boolean{
        val db=readableDatabase
        val selection="$TECH_EMAIL = ? "
        val selectionArgs=arrayOf(email)
        val cursor=db.query(TABLE_NAME_2,null,selection,selectionArgs,null,null,null)

        val techExists=cursor.count>0
        cursor.close()
        return techExists
    }
    //pairnoyme oloys toys techs me orismeno specializiation
    fun getTechs(specialization:String):List<Technician>{
            val techList= mutableListOf<Technician>()
            val db=readableDatabase
            val query="SELECT * FROM $TABLE_NAME_2 WHERE $TECH_AVAILABLE=1 AND $TECH_SPECIALIZATION= ? "
            val cursor=db.rawQuery(query,arrayOf(specialization))

        while(cursor.moveToNext()) {

           val tech=Technician(cursor.getString(1),cursor.getString(0),cursor.getString(2),cursor.getString(3)," "," ",1.0f," ")
            techList.add(tech)
        }
        cursor.close()
        db.close()
        return techList

    }
    fun getTechFromEmail(mail:String):List<Technician>{
        val techList= mutableListOf<Technician>()
        val db=readableDatabase
        val query="SELECT * FROM $TABLE_NAME_2 WHERE $TECH_EMAIL= ? "
        val cursor=db.rawQuery(query,arrayOf(mail))

        while(cursor.moveToNext()) {

            val tech=Technician(cursor.getString(1),cursor.getString(0),cursor.getString(2),cursor.getString(3)," "," ",1.0f," ")
            techList.add(tech)
        }
        cursor.close()
        db.close()
        return techList

    }
    fun getCustomer(usermail:String):List<Customer>{
        val customerList= mutableListOf<Customer>()
        val db=readableDatabase
        val query="SELECT * FROM $TABLE_NAME_1 WHERE $CUSTOMER_EMAIL= ? "
        val cursor=db.rawQuery(query,arrayOf(usermail))
        //email name password location

        while(cursor.moveToNext()) {
            //name mail password location
            val customer=Customer(cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(0))
            customerList.add(customer)
        }
        cursor.close()
        db.close()
        return customerList

    }

    fun getRequest(techmail:String):List<Request>{
        val requestList= mutableListOf<Request>()
        val db=readableDatabase
        val query="SELECT * FROM $TABLE_NAME_7 WHERE $REQUEST_TECH = ? "
        val cursor=db.rawQuery(query,arrayOf(techmail))

        while(cursor.moveToNext()) {

            var type= cursor.getString(1)
            var customermail=cursor.getString(4)
            var location=cursor.getString(3)
            var techSkills=cursor.getString(2)
                 val request=Request(type,customermail,techmail,location,techSkills)
                 requestList.add(request)
        }
        cursor.close()
        db.close()
        return requestList

    }
    fun updateCustomerPassword(customermail:String,newpassword:String){
        val values=ContentValues().apply{
            put(CUSTOMER_PASSWORD,newpassword)

        }
        val whereClause="$CUSTOMER_EMAIL =?"
        val whereArgs=arrayOf(customermail)
        val db=writableDatabase
        db.update(TABLE_NAME_1,values,whereClause,whereArgs)
        db.close()
    }
    fun updateCustomerUsername(customermail:String,newusername:String){
        val values=ContentValues().apply{
            put(CUSTOMER_NAME,newusername)

        }
        val whereClause="$CUSTOMER_EMAIL =?"
        val whereArgs=arrayOf(customermail)
        val db=writableDatabase
        db.update(TABLE_NAME_1,values,whereClause,whereArgs)
        db.close()
    }
    fun updateCustomerLocation(customermail:String,newlocation: String){
        val values=ContentValues().apply{
            put(CUSTOMER_LOCATION,newlocation)

        }
        val whereClause="$CUSTOMER_EMAIL =?"
        val whereArgs=arrayOf(customermail)
        val db=writableDatabase
        db.update(TABLE_NAME_1,values,whereClause,whereArgs)
        db.close()
    }
    fun updateTechPassword(techmail:String,newpassword:String){
        val values=ContentValues().apply{
            put(TECH_PASSWORD,newpassword)

        }
        val whereClause="$TECH_EMAIL =?"
        val whereArgs=arrayOf(techmail)
        val db=writableDatabase
        db.update(TABLE_NAME_2,values,whereClause,whereArgs)
        db.close()
    }
    fun updateTechLocation(techmail:String,newlocation:String){
        val values=ContentValues().apply{
            put(TECH_LOCATION,newlocation)

        }
        val whereClause="$TECH_EMAIL =?"
        val whereArgs=arrayOf(techmail)
        val db=writableDatabase
        db.update(TABLE_NAME_2,values,whereClause,whereArgs)
        db.close()
    }
    fun updateTechUsername(techmail:String,newusername:String){
        val values=ContentValues().apply{
            put(TECH_NAME,newusername)

        }
        val whereClause="$TECH_EMAIL =?"
        val whereArgs=arrayOf(techmail)
        val db=writableDatabase
        db.update(TABLE_NAME_2,values,whereClause,whereArgs)
        db.close()
    }
}