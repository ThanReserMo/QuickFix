package com.example.myapplication

import Technician
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ServiceReqsActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pending_requests)
        var usermail=intent.getStringExtra("usermail")
        var databaseHelper=DatabaseHelper(this)

        //onoma xrhsth prwtoy request
        var firstReq=findViewById<TextView>(R.id.firstRequestName)
        //accept request
        var firstAccept=findViewById<Button>(R.id.btnPick1)
        //deny request
        var firstDeny=findViewById<Button>(R.id.btnPick2)
        //omoiws
        var secondReq=findViewById<TextView>(R.id.secondRequestName)
        var secondAccept=findViewById<Button>(R.id.btnPick12)
        var secondDeny=findViewById<Button>(R.id.btnPick22)
        //omoiws
        var thirdReq=findViewById<TextView>(R.id.thirdRequestName)
        var thirdAccept=findViewById<Button>(R.id.btnPick13)
        var thirdDeny=findViewById<Button>(R.id.btnPick23)



        if(usermail!=null) {
          /*  var reqs = databaseHelper.getRequest(usermail)
            //vazoyme ta onomata twn xrhstwn sta textViews
            firstReq.text=reqs.get(0).customerMail
            secondReq.text=reqs.get(0).customerMail
           thirdReq.text=reqs.get(0).customerMail
            var type=databaseHelper.getTechFromEmail(usermail).get(0).specialization
            //1os customer stoixeia
            var firstCustomer=databaseHelper.getCustomer(reqs.get(0).customerMail).get(0)
            var firstLocation=firstCustomer.location
            //2os customer stoixeia
            var secondCustomer=databaseHelper.getCustomer(reqs.get(0).customerMail).get(0)
            var secondLocation=secondCustomer.location
            //3os customer stoixeia
            var thirdCustomer=databaseHelper.getCustomer(reqs.get(1).customerMail).get(0)
            var thirdLocation=thirdCustomer.location*/

            firstAccept.setOnClickListener{
               //databaseHelper.insertProblem(1,type," ",firstLocation,firstCustomer.email,usermail)
                Toast.makeText(this,"Problem inserted", Toast.LENGTH_SHORT).show()

            }
            firstDeny.setOnClickListener{
               Toast.makeText(this,"Request Rejected", Toast.LENGTH_SHORT).show()
            }
            secondAccept.setOnClickListener{
              // databaseHelper.insertProblem(1,type," ",secondLocation,secondCustomer.email,usermail)
                Toast.makeText(this,"Problem inserted", Toast.LENGTH_SHORT).show()

            }
            secondDeny.setOnClickListener{
                Toast.makeText(this,"Request Rejected", Toast.LENGTH_SHORT).show()

            }
            thirdAccept.setOnClickListener{
               // databaseHelper.insertProblem(1,type," ",thirdLocation,thirdCustomer.email,usermail)
                Toast.makeText(this,"Problem inserted", Toast.LENGTH_SHORT).show()

            }
            thirdDeny.setOnClickListener{
                Toast.makeText(this,"Request Rejected", Toast.LENGTH_SHORT).show()


            }


        }


    }
}