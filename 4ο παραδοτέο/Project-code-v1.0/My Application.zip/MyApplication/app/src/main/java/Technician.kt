import java.io.Serializable

class Technician(inputName:String, inputEmail:String,inputPassword:String,inputLocation:String, inputSkills:String, inputSpecialization:String,
                 inputRating:Float, inputTechnicalSkills:String):Serializable {
    var name:String=inputName
    var email:String=inputEmail
    var password:String=inputPassword
    var location:String=inputLocation
    var skills:String=inputSkills
    var specialization:String=inputSpecialization
    var ratings:Float=inputRating
    var technicalSkills:String=inputTechnicalSkills
}