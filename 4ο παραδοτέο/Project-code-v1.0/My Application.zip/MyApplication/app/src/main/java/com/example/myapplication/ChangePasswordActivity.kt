package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ChangePasswordActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)
        // elegxoyme an erxomaste apo customer h apo tech
        val btnConfirm=findViewById<Button>(R.id.confirmAccountButton)
        var databaseHelper=DatabaseHelper(this)

        //o logos poy prepei na kanoyme ola ta actions entws toy if
        //kai oxi apla to assignment toy usermail
        //einai logo toy pws doyleyei to scope stin kotlin

        //ara exoyme to programma se periptwsi poy erxomaste apo customer
        if(intent.getStringExtra("from")=="customer") {
            //pairnoyme to mail toy xrhsth
            var usermail = intent.getStringExtra("usermail")

            //xristis pataei koympi confirm
            btnConfirm.setOnClickListener {
                //pairnoyme to inputted palio password
                var oldPassword = findViewById<EditText>(R.id.editPasswordOld).getText().toString()
                var newPassword=findViewById<EditText>(R.id.editPasswordNew).getText().toString()
                var newPasswordAgain=findViewById<EditText>(R.id.editPasswordNewAgain).getText().toString()
                //Toast.makeText(this,"Password changed successfully", Toast.LENGTH_SHORT).show()

                //pairnoyme to password toy customer apo to database
                if (usermail != null) {
                    var oldPasswordFromDB=  databaseHelper.getCustomer(usermail).get(0).password
                    if(oldPassword==oldPasswordFromDB && newPassword==newPasswordAgain){
                        databaseHelper.updateCustomerPassword(usermail,newPassword)
                        Toast.makeText(this,"Password changed successfully", Toast.LENGTH_SHORT).show()

                    }
                }

            }

        }else if(intent.getStringExtra("from")=="tech"){
            //pairnoyme to mail toy xrhsth
            var usermail = intent.getStringExtra("usermail")

            //xristis pataei koympi confirm
            btnConfirm.setOnClickListener {
                //pairnoyme to inputted palio password
                var oldPassword = findViewById<EditText>(R.id.editPasswordOld).getText().toString()
                var newPassword=findViewById<EditText>(R.id.editPasswordNew).getText().toString()
                var newPasswordAgain=findViewById<EditText>(R.id.editPasswordNewAgain).getText().toString()
                //Toast.makeText(this,"Password changed successfully", Toast.LENGTH_SHORT).show()

                //pairnoyme to password toy customer apo to database
                if (usermail != null) {
                    var oldPasswordFromDB=  databaseHelper.getTechFromEmail(usermail).get(0).password
                    if(oldPassword==oldPasswordFromDB && newPassword==newPasswordAgain){
                        databaseHelper.updateTechPassword(usermail,newPassword)
                        Toast.makeText(this,"Password changed successfully", Toast.LENGTH_SHORT).show()

                    }
                }

            }

        }



    }
}