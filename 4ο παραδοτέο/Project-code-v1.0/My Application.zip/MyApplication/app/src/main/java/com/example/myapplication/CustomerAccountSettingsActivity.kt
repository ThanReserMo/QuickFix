package com.example.myapplication

import Customer
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class CustomerAccountSettingsActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer_settings)
        var usermail=intent.getStringExtra("usermail")

        var btnChangePassword=findViewById<Button>(R.id.passwordButton)
        var btnChangeUsername=findViewById<Button>(R.id.ChangeUsername)
        var btnChangeLocation=findViewById<Button>(R.id.locationButton)

        //allagi password
        btnChangePassword.setOnClickListener{
            Intent(this, ChangePasswordActivity::class.java).also {
                //stelnoyme ta stoixeia kai
                //to oti proerxomaste apo customer
                it.putExtra("usermail",usermail)
                it.putExtra("from","customer")
                startActivity(it)
            }
        }
        //allagi username
        btnChangeUsername.setOnClickListener{
            Intent(this, ChangeUsernameActivity::class.java).also {
                //stelnoyme ta stoixeia kai
                //to oti proerxomaste apo customer
                it.putExtra("usermail",usermail)
                it.putExtra("from","customer")
                startActivity(it)
            }

        }
        btnChangeLocation.setOnClickListener{
            Intent(this, SetLocationActivity::class.java).also {
                //stelnoyme ta stoixeia kai
                //to oti proerxomaste apo customer
                it.putExtra("usermail",usermail)
                it.putExtra("from","customer")
                startActivity(it)
            }

        }
    }
}