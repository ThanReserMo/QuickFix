import java.util.Date

class Review(inputRateID:String, inputRating:Int, inputComment:String, inputDate:Date) {
    val rateID:String=inputRateID
    val rating:Int=inputRating
    val comment:String=inputComment
    val date:Date=inputDate
}