package com.example.myapplication

import Customer
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class SelectProblemActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_service_selection)

        val usermail=intent.getStringExtra("usermail")
        val btnElectric=findViewById<Button>(R.id.electricProblemButton)
        val btnPlumber=findViewById<Button>(R.id.plumbingButton)
        val btnACRepair=findViewById<Button>(R.id.acRepairButton)
        val btnAppRepair=findViewById<Button>(R.id.applianceButton)

        btnElectric.setOnClickListener{
            Intent(this, SelectTechActivity::class.java).also {
                 it.putExtra("from","Electrician")
                it.putExtra("usermail",usermail)
                startActivity(it)
            }
        }
        btnPlumber.setOnClickListener{
            Intent(this, SelectTechActivity::class.java).also {
                it.putExtra("from","Plumber")
                it.putExtra("usermail",usermail)

                startActivity(it)
            }
        }
        btnACRepair.setOnClickListener{
            Intent(this, SelectTechActivity::class.java).also {
                it.putExtra("from","ACRepair")
                it.putExtra("usermail",usermail)

                startActivity(it)
            }
        }
        btnAppRepair.setOnClickListener{
            Intent(this, SelectTechActivity::class.java).also {
                it.putExtra("from","AppRepair")
                it.putExtra("usermail",usermail)

                startActivity(it)
            }
        }

    }
}