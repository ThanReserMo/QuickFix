package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ChangeUsernameActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_username)
        var databaseHelper=DatabaseHelper(this)

        var btnConfirmNewUsername=findViewById<Button>(R.id.confirmNewUsername)

        //tha xrisimopoihsoyme ayto to view gia na
        //diksoyme to paron username
        var currentUsername=findViewById<TextView>(R.id.enterCurrentUsernameHere)



        //o logos poy prepei na kanoyme ola ta actions entws toy if
        //kai oxi apla to assignment toy usermail
        //einai logo toy pws doyleyei to scope stin kotlin

        //ara exoyme to programma se periptwsi poy erxomaste apo customer
        if(intent.getStringExtra("from")=="customer") {
            //pairnoyme to mail toy xrhsth
            var usermail = intent.getStringExtra("usermail")

            if (usermail != null) {
                //thetoyme to textView sto paron username
                currentUsername.text = databaseHelper.getCustomer(usermail).get(0).name
            }

            //xristis pataei koympi confirm
            btnConfirmNewUsername.setOnClickListener {
                //pairnoyme to neo username
                var newUsername = findViewById<EditText>(R.id.editNewUsername).getText().toString()


                if (usermail != null) {
                    databaseHelper.updateCustomerUsername(usermail,newUsername)
                    Toast.makeText(this,"Username changed successfully", Toast.LENGTH_SHORT).show()
                    //ananewnoyme to Current Username:
                    currentUsername.text = databaseHelper.getCustomer(usermail).get(0).name

                }


            }

        }else if(intent.getStringExtra("from")=="tech"){
            //pairnoyme to mail toy xrhsth
            var usermail = intent.getStringExtra("usermail")


            if (usermail != null) {
                //thetoyme to textView sto paron username
                currentUsername.text = databaseHelper.getTechFromEmail(usermail).get(0).name
            }


            //xristis pataei koympi confirm
            btnConfirmNewUsername.setOnClickListener {
                var usermail = intent.getStringExtra("usermail")

                if (usermail != null) {
                    //thetoyme to textView sto paron username
                    currentUsername.text = databaseHelper.getTechFromEmail(usermail).get(0).name
                }
                //pairnoyme to neo username
                var newUsername = findViewById<EditText>(R.id.editNewUsername).getText().toString()


                if (usermail != null) {
                    databaseHelper.updateTechUsername(usermail,newUsername)
                    Toast.makeText(this,"Username changed successfully", Toast.LENGTH_SHORT).show()
                    //ananewnoyme to CurrentUsername
                    currentUsername.text = databaseHelper.getTechFromEmail(usermail).get(0).name


                }


            }

        }
    }
}