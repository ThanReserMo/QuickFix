import android.app.Application
import android.os.Parcel
import android.os.Parcelable
import android.provider.ContactsContract.CommonDataKinds.Email
import java.io.Serializable

 class Customer(inputtedName: String,inputtedPassword: String,inputtedLocation:String,inputtedEmail: String) :Serializable {
    var name =inputtedName
    var email = inputtedEmail
    var location =inputtedLocation

    var password =inputtedPassword

    //support variable gia na ginetai true/false me login sign in
    var isSignedIn: Boolean=true



     fun getmyName():String{
         return this.name
     }
     fun getmyPassword():String{
         return this.password
     }





    //unit sto kotlin antistoixo toy null
    //pairnoyme to name kai password poy egrapse o xristis kai elegxoyme an einai swsta
    fun signIn(inputtedEmail: String,inputtedPassword:String): Unit{
        if(inputtedEmail==this.email && inputtedPassword==this.password) {
            this.isSignedIn = true
            //gia debugging
            println("Sign in Success")
        }else{
            println("Sign In failed")
        }
    }
    fun logOut(): Unit{
        this.isSignedIn=false
    }
    //theoroyme oti to createAccount einai to constructor kai ginete mesw twn inputs (inputName klp)
    fun help():Unit{}

    fun editUsername(newUsername:String):Unit{
        this.name=newUsername
    }
    fun changePassword(oldPassword:String,newPassword:String):Unit{
        if(oldPassword==this.password) {
            this.password = newPassword
        }else {
            //edw tha htan kalo na ftiaxtei ena toast (android)
         println("Old password did not match")
        }
    }
    //ws set location yphrxe provlhma me ta declarations
    fun setNewLocation(newLocation:String):Unit{
        this.location=newLocation
    }






 }