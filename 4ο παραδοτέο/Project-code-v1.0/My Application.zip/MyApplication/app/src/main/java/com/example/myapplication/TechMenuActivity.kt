package com.example.myapplication

import Technician
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class TechMenuActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_tech)
       // val btnSignUpConfirm = findViewById<View>(R.id.confirmAccountButton)

       // val techFromSignUp=intent.getSerializableExtra("techFromSignUp") as Technician
        //pairnoyme to email tou user
        var usermail=intent.getStringExtra("usermail")

        //orizoyme buttons
        val btnViewServiceReqs=findViewById<Button>(R.id.viewServiceRequestsButton)
        val btnAccountSettings=findViewById<Button>(R.id.accountSettingsButton)
        val btnHelp=findViewById<Button>(R.id.helpButton)

        //transition gia viewServiceRequests
        btnViewServiceReqs.setOnClickListener{
            Intent(this,ServiceReqsActivity::class.java).also{
                it.putExtra("usermail",usermail)
                startActivity(it)
            }
        }
        //transition gia Settings
        btnAccountSettings.setOnClickListener{
            Intent(this,TechAccountSettingsActivity::class.java).also{
               it.putExtra("usermail",usermail)
                startActivity(it)
            }
        }

        }
    }
