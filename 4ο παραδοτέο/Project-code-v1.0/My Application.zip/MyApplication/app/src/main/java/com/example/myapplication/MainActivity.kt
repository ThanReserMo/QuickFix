package com.example.myapplication

import Customer
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.View
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {


   private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var databaseHelper=DatabaseHelper(this)

        //val customer1= Customer("Iannis Pelatis","1234", "Dim Vots. 3", "email@gmail.com")
        val insertedRowId1=databaseHelper.insertTech("firstTech@gmail.com","1234","Iannis Elektro","Dim Vots 3","PH","Ilektrikos",1.0f,1)
        val insertedRowId2=databaseHelper.insertTech("secondTech@gmail.com","1234","Kostas Elektro","Dim Vots 3","PH","Ilektrikos",1.0f,1)
        val insertedRowId3=databaseHelper.insertTech("thirdTech@gmail.com","1234","Giorgos Elektro","Dim Vots 3","PH","Ilektrikos",1.0f,1)

        val insertedRowId4=databaseHelper.insertTech("fourthTech@gmail.com","1234","Iannis Plumber","Dim Vots 3","PH","Plumber",1.0f,1)
        val insertedRowId5=databaseHelper.insertTech("fifthTech@gmail.com","1234","Kostas Plumber","Dim Vots 3","PH","Plumber",1.0f,1)
        val insertedRowId6=databaseHelper.insertTech("sixthTech@gmail.com","1234","Giorgos Plumber","Dim Vots 3","PH","Plumber",1.0f,1)

        val insertedRowId7=databaseHelper.insertTech("seventhTech@gmail.com","1234","Iannis ACRepair","Dim Vots 3","PH","ACRepair",1.0f,1)
        val insertedRowId8=databaseHelper.insertTech("eighthTech@gmail.com","1234","Kostas ACRepair","Dim Vots 3","PH","ACRepair",1.0f,1)
        val insertedRowId9=databaseHelper.insertTech("ninthTech@gmail.com","1234","Giorgos ACRepair","Dim Vots 3","PH","ACRepair",1.0f,1)

        val insertedRowId10=databaseHelper.insertTech("tenthTech@gmail.com","1234","Iannis AppRepair","Dim Vots 3","PH","AppRepair",1.0f,1)
        val insertedRowId11=databaseHelper.insertTech("eleventhTech@gmail.com","1234","Kostas AppRepair","Dim Vots 3","PH","AppRepair",1.0f,1)
        val insertedRowId12=databaseHelper.insertTech("twelvethTech@gmail.com","1234","Giorgos AppRepair","Dim Vots 3","PH","AppRepair",1.0f,1)

        val insert1=databaseHelper.insertCustomer("firstCustomer@gmail.com","1234","Iannis Customer","Dim Votsi 8")
        val insert2=databaseHelper.insertCustomer("secondCustomer@gmail.com","1234","Giorgos Customer","Dim Votsi 8")
        val insert3=databaseHelper.insertCustomer("thirdCustomer@gmail.com","1234","Kostas Customer","Dim Votsi 8")
        val insert4=databaseHelper.insertRequest(1," "," ","Dim Votsi 8","firstCustomer@gmail.com","techmail@gmail.com")
        val insert5=databaseHelper.insertRequest(1," "," ","Dim Votsi 8","secondCustomer@gmail.com","techmail@gmail.com")
        val insert6=databaseHelper.insertRequest(1," "," ","Dim Votsi 8","thirdCustomer@gmail.com","techmail@gmail.com")


        //default to create_account
        setContentView(R.layout.activity_create_account)
        //click to signUpCustomer gia na pame sto signUpScreen
        val btnSignUpCustomer=findViewById<View>(R.id.signUpCustomerButton)
        btnSignUpCustomer.setOnClickListener{
            println("check 1")
            Intent(this,SignUpCustomerActivity::class.java).also{
                startActivity(it)
            }
        }
        //click to signUpTech gia na pame sto signUpTech
        val btnSignUpTech=findViewById<View>(R.id.signUpTechButton)
        btnSignUpTech.setOnClickListener {
            Intent(this, SignUpTechActivity::class.java).also {
                startActivity(it)
            }
        }
        //click gia signIn
        val btnSignIn=findViewById<View>(R.id.signInButton)
        btnSignIn.setOnClickListener{
            
            Intent(this,SignInActivity::class.java).also{
              //  it.putExtra("customer1",customer1)
                startActivity(it)
            }

        }

        }

    }
