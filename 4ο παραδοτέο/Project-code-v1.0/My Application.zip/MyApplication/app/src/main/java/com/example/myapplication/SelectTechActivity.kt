package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SelectTechActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select)
        var usermail=intent.getStringExtra("usermail")
        var databaseHelper=DatabaseHelper(this)
        //edw oysiastika allazoyme dynamika ta textViews analoga me to
        //ti provlima exei o customer
        var selectText=findViewById<TextView>(R.id.titleText)
        var firstTech=findViewById<TextView>(R.id.FirstTech)
        var secondTech=findViewById<TextView>(R.id.SecondTech)
        var thirdTech=findViewById<TextView>(R.id.ThirdTech)

        var tech1=findViewById<Button>(R.id.btnPick1)
        var tech2=findViewById<Button>(R.id.btnPick2)
        var tech3=findViewById<Button>(R.id.btnPick3)

        if(intent.getStringExtra("from")=="Electrician"){
            selectText.text="Select Electrician"
            //Pairnoyme ta onomata twn texnikwn mesw
            //tis sqlite function mas
            //kai vazoyme ta onomata sta textViews
            var techList=databaseHelper.getTechs("Ilektrikos")
            firstTech.text=techList.get(0).name
            secondTech.text=techList.get(1).name
            thirdTech.text=techList.get(2).name

            //kanoyme insert to request me to
            //mail toy user kai to mail toy tech
            tech1.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"Electric"," "," ",usermail,techList.get(0).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(0).email)
                        startActivity(it)
                    }

                }
            }
            tech2.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"Electric"," "," ",usermail,techList.get(1).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(1).email)
                        startActivity(it)
                    }

                }
            }
            tech3.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"Electric"," "," ",usermail,techList.get(2).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(2).email)
                        startActivity(it)
                    }

                }
            }


        }else if(intent.getStringExtra("from")=="Plumber"){
            selectText.text="Select Plumber"
            var techList=databaseHelper.getTechs("Plumber")
            firstTech.text=techList.get(0).name
            secondTech.text=techList.get(1).name
            thirdTech.text=techList.get(2).name

            tech1.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"Plumbing"," "," ",usermail,techList.get(0).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(0).email)
                        startActivity(it)
                    }

                }
            }
            tech2.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"Plumbing"," "," ",usermail,techList.get(1).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(1).email)
                        startActivity(it)
                    }

                }
            }
            tech3.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"Plumbing"," "," ",usermail,techList.get(2).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(2).email)
                        startActivity(it)
                    }

                }
            }
        }else if(intent.getStringExtra("from")=="ACRepair"){
            selectText.text="Select AC Repair Expert"
            var techList=databaseHelper.getTechs("ACRepair")
            firstTech.text=techList.get(0).name
            secondTech.text=techList.get(1).name
            thirdTech.text=techList.get(2).name

            tech1.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"ACRepair"," "," ",usermail,techList.get(0).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(0).email)
                        startActivity(it)
                    }

                }
            }
            tech2.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"ACRepair"," "," ",usermail,techList.get(1).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(1).email)
                        startActivity(it)
                    }

                }
            }
            tech3.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"ACRepair"," "," ",usermail,techList.get(2).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(2).email)
                        startActivity(it)
                    }

                }
            }
        }else if(intent.getStringExtra("from")=="AppRepair"){
            selectText.text="Select Appliance repair expert"
            var techList=databaseHelper.getTechs("AppRepair")
            firstTech.text=techList.get(0).name
            secondTech.text=techList.get(1).name
            thirdTech.text=techList.get(2).name

            tech1.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"AppRepair"," "," ",usermail,techList.get(0).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(0).email)
                        startActivity(it)
                    }

                }
            }
            tech2.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"AppRepair"," "," ",usermail,techList.get(1).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(1).email)
                        startActivity(it)
                    }

                }
            }
            tech3.setOnClickListener{
                if (usermail != null) {
                    databaseHelper.insertRequest(1,"AppRepair"," "," ",usermail,techList.get(2).email)
                    Toast.makeText(this,"Request Inserted", Toast.LENGTH_SHORT).show()
                    Intent(this, AwaitingResponseActivity::class.java).also {
                        it.putExtra("customermail", usermail )
                        it.putExtra("techmail", techList.get(2).email)
                        startActivity(it)
                    }

                }
            }
        }
    }
}