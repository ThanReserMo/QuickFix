package com.example.myapplication

import Technician
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class TechAccountSettingsActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tech_settings)
       // val techFromSignUp=intent.getSerializableExtra("techFromSignUp") as Technician

        var usermail=intent.getStringExtra("usermail")

        var btnChangePassword=findViewById<Button>(R.id.passwordButton)
        var btnChangeUsername=findViewById<Button>(R.id.ChangeUsernameTech)
        var btnSetLocation=findViewById<Button>(R.id.setLocation)

        btnChangePassword.setOnClickListener{
            Intent(this,ChangePasswordActivity::class.java).also{
                //stelnoyme to email toy tech
                it.putExtra("usermail",usermail)
                //dilonoyme oti erxomaste apo tech Settings
                it.putExtra("from","tech")
                startActivity(it)
            }
        }
        btnChangeUsername.setOnClickListener{
            Intent(this,ChangeUsernameActivity::class.java).also{
                //stelnoyme to email toy tech
                it.putExtra("usermail",usermail)
                //dilonoyme oti erxomaste apo tech Settings
                it.putExtra("from","tech")
                startActivity(it)
            }

        }
        btnSetLocation.setOnClickListener {
            Intent(this, SetLocationActivity::class.java).also {
                //stelnoyme to email toy tech
                it.putExtra("usermail", usermail)
                //dilonoyme oti erxomaste apo tech Settings
                it.putExtra("from", "tech")
                startActivity(it)

            }
        }

    }
}