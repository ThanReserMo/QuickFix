package com.example.myapplication

import Customer
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MenuActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)
        //pairnoyme to email toy user
        var usermail=intent.getStringExtra("usermail")

        val btnSelectProblem = findViewById<Button>(R.id.selectProblemButton)
        val btnAccountSettings = findViewById<Button>(R.id.accountSettingsButton)
        btnSelectProblem.setOnClickListener {


            Intent(this, SelectProblemActivity::class.java).also {
                it.putExtra("usermail",usermail)
                startActivity(it)
            }


        }
        btnAccountSettings.setOnClickListener {

            Intent(this, CustomerAccountSettingsActivity::class.java).also {
                it.putExtra("usermail",usermail)

                startActivity(it)
            }

            }
        }
    }
