class Problem(inputProblemID:String,inputType:String,inputDescription:String,inputLocation:String) {
    val problemID:String=inputProblemID
    val type:String=inputType
    val description:String=inputDescription
    //to location to pairnoyme apo to customer class
    val location:String=inputLocation
}