
class Technician(inputName:String, inputEmail:String, inputLocation:String, inputSkills:String, inputSpecialization:String,
                 inputRating:Float, inputTechnicalSkills:String) {
    var name:String=inputName
    var email:String=inputEmail
    var location:String=inputLocation
    var skills:String=inputSkills
    var specialization:String=inputSpecialization
    var ratings:Float=inputRating
    var technicalSkills:String=inputTechnicalSkills
}