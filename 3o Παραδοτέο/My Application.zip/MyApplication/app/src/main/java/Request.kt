class Request(inputRequestType:String,inputEmail:String,inputAddress:String,inputTechnicalSkills:String) {
    val requestType:String=inputRequestType
    //edw to email tha to paroyme apo ton user mesw toy input toy class
    val email:String=inputEmail
    //omoiws
    val address:String=inputAddress

    val technicalSkills:String=inputTechnicalSkills

}